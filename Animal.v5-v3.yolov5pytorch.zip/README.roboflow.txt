
Animal - v5 V3
==============================

This dataset was exported via roboflow.ai on April 1, 2021 at 4:47 AM GMT

It includes 84 images.
Husky are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random Gaussian blur of between 0 and 6 pixels


