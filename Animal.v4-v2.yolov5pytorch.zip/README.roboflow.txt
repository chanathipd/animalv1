
Animal - v4 V2
==============================

This dataset was exported via roboflow.ai on April 1, 2021 at 4:45 AM GMT

It includes 90 images.
Husky are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Random shear of between -4° to +4° horizontally and -27° to +27° vertically


