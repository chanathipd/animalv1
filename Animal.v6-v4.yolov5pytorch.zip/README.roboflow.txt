
Animal - v6 V4
==============================

This dataset was exported via roboflow.ai on April 1, 2021 at 4:48 AM GMT

It includes 90 images.
Husky are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Randomly crop between 0 and 35 percent of the image
* Random shear of between -4° to +4° horizontally and -41° to +41° vertically
* Random brigthness adjustment of between -47 and +47 percent


